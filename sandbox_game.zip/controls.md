Movement:

W: Move Up (Forward)
A: Move Left
S: Move Down (Backward)
D: Move Right

Actions:

B: Break (Destroy) Block at Player's Position
P: Place Sand Block at Player's Position
T: Place Dirt Block at Player's Position
L: Place Water Block at Player's Position
E: Place Fire Block at Player's Position
J: Place Dust Block at Player's Position
I: Place Ice Block at Player's Position
N: Place Liquid Nitrogen Block at Player's Position
F: Toggle Advancements Window

How to win ?:
You need to destroy all of the sand blocks generated on the map.

How to get advancements ?:
Gardener advancement>Place 50 water block [L] key
Winner advancement>Win 5 times
Shovel advancement>Break 100 sand blocks

