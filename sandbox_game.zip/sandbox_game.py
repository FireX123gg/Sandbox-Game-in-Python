import pygame
import sys
import random

# Initialize Pygame
pygame.init()

# Constants
WIDTH, HEIGHT = 800, 600
BLOCK_SIZE = 20
SAND_COLOR = (255, 255, 0)
DIRT_COLOR = (139, 69, 19)  # Brown
WATER_COLOR = (0, 0, 255)
PLAYER_COLOR = (0, 128, 255)
FIRE_COLOR = (255, 0, 0)
DUST_COLOR = (192, 192, 192)
ICE_COLOR = (173, 216, 230)  # Light Blue
LIQUID_NITROGEN_COLOR = (0, 255, 255)  # Cyan
WIN_TEXT_COLOR = (255, 255, 255)

# Player starting position
player_x, player_y = WIDTH // 2, HEIGHT // 2
player_speed = 5

# Create the game window
screen = pygame.display.set_mode((WIDTH, HEIGHT))
pygame.display.set_caption("Sandbox Game")

# Create sand blocks
sand_blocks = [(random.randint(0, WIDTH - BLOCK_SIZE), random.randint(0, HEIGHT - BLOCK_SIZE))
               for _ in range(100)]

# Create advancements
advancements = {"Gardener": 50, "Winner": 5, "Shovel": 100}
player_advancements = {"Gardener": 0, "Winner": 0, "Shovel": 0}

# Water physics
water_blocks = []

# Dirt blocks
dirt_blocks = []

# Dust blocks
dust_blocks = []

# Fire blocks
fire_blocks = []

# Ice blocks
ice_blocks = []

# Liquid nitrogen blocks
liquid_nitrogen_blocks = []

# Advancements window flag
advancements_visible = False

# Flag to control the game loop
running = True

# Function to check and update advancements
def check_advancements():
    for adv, count in advancements.items():
        if player_advancements[adv] == -1:
            continue  # Skip achieved advancements
        if player_advancements[adv] >= count:
            print(f"Achievement Unlocked: {adv}!")
            player_advancements[adv] = -1  # Mark it as achieved

# Function to display advancements window
def display_advancements_window():
    advancements_window = pygame.Surface((200, 150))
    advancements_window.fill((255, 255, 255))
    font = pygame.font.Font(None, 24)
    text_y = 20
    for adv, count in player_advancements.items():
        if count != -1:
            text = font.render(f"{adv}: {count}/{advancements[adv]}", True, (0, 0, 0))
            advancements_window.blit(text, (10, text_y))
            text_y += 30
    screen.blit(advancements_window, (WIDTH // 2 - 100, HEIGHT // 2 - 75))
    pygame.display.flip()

# Function to check if a block is nearby
def is_nearby(x1, y1, x2, y2, distance=BLOCK_SIZE):
    return abs(x1 - x2) <= distance and abs(y1 - y2) <= distance

# Function to check if liquid nitrogen touches nearby blocks and turns them into ice
def check_liquid_nitrogen_collision():
    for nitrogen_block in liquid_nitrogen_blocks:
        nitrogen_x, nitrogen_y = nitrogen_block[0], nitrogen_block[1]

        # Check if liquid nitrogen touches nearby blocks and turn them into ice
        for block in sand_blocks + dirt_blocks:
            if is_nearby(nitrogen_x, nitrogen_y, block[0], block[1]):
                ice_block = (block[0], block[1])
                ice_blocks.append(ice_block)
                if block in sand_blocks:
                    sand_blocks.remove(block)
                elif block in dirt_blocks:
                    dirt_blocks.remove(block)

# Function to check if fire touches water
def check_fire_water_collision():
    for fire_block in fire_blocks:
        fire_x, fire_y = fire_block[0], fire_block[1]

        # Check if fire touches water
        for water_block in water_blocks:
            if is_nearby(fire_x, fire_y, water_block[0], water_block[1]):
                fire_blocks.remove(fire_block)
                break

# Function to check if fire touches nearby blocks and turns them into dust
def check_fire_nearby_collision():
    for fire_block in fire_blocks:
        fire_x, fire_y = fire_block[0], fire_block[1]

        # Check if fire touches nearby blocks and turn them into dust
        for block in sand_blocks + dirt_blocks:
            if is_nearby(fire_x, fire_y, block[0], block[1]):
                dust_block = (block[0], block[1])
                dust_blocks.append(dust_block)
                if block in sand_blocks:
                    sand_blocks.remove(block)
                elif block in dirt_blocks:
                    dirt_blocks.remove(block)

# Game loop
while running:
    try:
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                running = False
            elif event.type == pygame.KEYDOWN:
                if event.key == pygame.K_b:
                    # Destroy any block at player's position
                    for block_list in [sand_blocks, dirt_blocks, fire_blocks, water_blocks, dust_blocks, ice_blocks, liquid_nitrogen_blocks]:
                        for block in block_list:
                            if player_x < block[0] < player_x + BLOCK_SIZE and player_y < block[1] < player_y + BLOCK_SIZE:
                                block_list.remove(block)
                                player_advancements["Shovel"] += 1
                elif event.key == pygame.K_t:
                    # Place dirt block at player's position
                    dirt_block = (player_x, player_y)
                    dirt_blocks.append(dirt_block)
                elif event.key == pygame.K_p:
                    # Place sand block at player's position
                    sand_block = (player_x, player_y)
                    sand_blocks.append(sand_block)
                elif event.key == pygame.K_l:
                    # Place water block at player's position
                    water_block = [player_x, player_y, BLOCK_SIZE, BLOCK_SIZE]
                    water_blocks.append(water_block)
                    player_advancements["Gardener"] += 1
                elif event.key == pygame.K_e:
                    # Place fire block at player's position
                    fire_block = [player_x, player_y, BLOCK_SIZE, BLOCK_SIZE]
                    fire_blocks.append(fire_block)
                elif event.key == pygame.K_f:
                    # Toggle advancements window visibility
                    advancements_visible = not advancements_visible
                elif event.key == pygame.K_j:
                    # Place dust block at player's position
                    dust_block = (player_x, player_y)
                    dust_blocks.append(dust_block)
                elif event.key == pygame.K_i:
                    # Place ice block at player's position
                    ice_block = (player_x, player_y)
                    ice_blocks.append(ice_block)
                elif event.key == pygame.K_n:
                    # Place liquid nitrogen block at player's position
                    nitrogen_block = [player_x, player_y, BLOCK_SIZE, BLOCK_SIZE]
                    liquid_nitrogen_blocks.append(nitrogen_block)

        keys = pygame.key.get_pressed()
        if keys[pygame.K_w]:
            player_y -= player_speed
        if keys[pygame.K_s]:
            player_y += player_speed
        if keys[pygame.K_a]:
            player_x -= player_speed
        if keys[pygame.K_d]:
            player_x += player_speed

        # Water physics
        for water_block in water_blocks:
            water_block[1] += 2  # Fall down
            if water_block[1] + BLOCK_SIZE > HEIGHT:
                water_block[1] = HEIGHT - BLOCK_SIZE  # Stop at the bottom

        # Liquid nitrogen physics and collision
        for nitrogen_block in liquid_nitrogen_blocks:
            nitrogen_block[1] += 2  # Fall down
            if nitrogen_block[1] + BLOCK_SIZE > HEIGHT:
                nitrogen_block[1] = HEIGHT - BLOCK_SIZE  # Stop at the bottom

        # Fire physics and collision
        for fire_block in fire_blocks:
            fire_block[1] -= 2  # Rise up
            if fire_block[1] < 0:
                fire_blocks.remove(fire_block)  # Remove if above the screen

        # Check if liquid nitrogen touches nearby blocks and turns them into ice
        check_liquid_nitrogen_collision()

        # Check if fire touches water
        check_fire_water_collision()

        # Check if fire touches nearby blocks and turns them into dust
        check_fire_nearby_collision()

        # Draw sand blocks
        screen.fill((0, 0, 0))
        for block in sand_blocks:
            pygame.draw.rect(screen, SAND_COLOR, (*block, BLOCK_SIZE, BLOCK_SIZE))

        # Draw dirt blocks
        for dirt_block in dirt_blocks:
            pygame.draw.rect(screen, DIRT_COLOR, (*dirt_block, BLOCK_SIZE, BLOCK_SIZE))

        # Draw water blocks
        for water_block in water_blocks:
            pygame.draw.rect(screen, WATER_COLOR, water_block)

        # Draw fire blocks
        for fire_block in fire_blocks:
            pygame.draw.rect(screen, FIRE_COLOR, fire_block)

        # Draw ice blocks
        for ice_block in ice_blocks:
            pygame.draw.rect(screen, ICE_COLOR, (*ice_block, BLOCK_SIZE, BLOCK_SIZE))

        # Draw liquid nitrogen blocks
        for nitrogen_block in liquid_nitrogen_blocks:
            pygame.draw.rect(screen, LIQUID_NITROGEN_COLOR, nitrogen_block)

        # Draw dust blocks
        for dust_block in dust_blocks:
            pygame.draw.rect(screen, DUST_COLOR, (*dust_block, BLOCK_SIZE, BLOCK_SIZE))

        # Draw player
        pygame.draw.rect(screen, PLAYER_COLOR, (player_x, player_y, BLOCK_SIZE, BLOCK_SIZE))

        # Draw advancements window if visible
        if advancements_visible:
            display_advancements_window()

        pygame.display.flip()
        pygame.time.Clock().tick(30)

    except Exception as e:
        print("An error occurred:", e)
        pygame.quit()
        sys.exit()
